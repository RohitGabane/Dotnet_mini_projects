﻿
CREATE PROCEDURE Ronny
       @pname     NVARCHAR(Max), 
       @pBalance    float
               
AS 
BEGIN 
  INSERT INTO dbo.Account( Name ,Balance)    VALUES (@pname , @pBalance  )
 End
