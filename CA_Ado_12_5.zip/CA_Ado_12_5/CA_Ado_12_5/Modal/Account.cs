﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA_Ado_12_5.Modal
{
    internal class Account
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public float? Balance { get; set; }

    }
}
